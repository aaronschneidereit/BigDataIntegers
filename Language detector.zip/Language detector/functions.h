/**
 * Started by Najib 3/21/18
 **/

#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__

#include "bigint/bigint.h"
#include <iostream>
#include <vector>
#include <string>
#include <stdint.h>
#include <fstream>
#include <iostream>
#include <cmath>

///////////////////////////////////////////////////////////////////
// FUNCTION HEADERS GO HERE
///////////////////////////////////////////////////////////////////


class frequencies{

  private:
  std:: vector <int> triFreq; //creates the vector to be used

  //vectors for all the different testing_languages files to be used
  public:

    frequencies(); // default constructor
    frequencies(std::string filename);//parametrized constructor
    double similarity(frequencies languageFreq); //find simliarity value between the training file and the test
    std::vector<int> getTriFreq();

};

#endif