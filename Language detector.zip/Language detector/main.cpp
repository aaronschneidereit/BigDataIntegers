/**
 * Started by Najib 3/21/18
 **/

///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include "functions.h"
#include "bigint/bigint.h"


int main(int argc, char *argv[]) {
    ///////////////////////////////////////////////////////////////////
    // MAKE YOUR OWN MAIN.
    ///////////////////////////////////////////////////////////////////

    //creates a vector of triFreqsfre

    std::vector <frequencies> languageFreq;

    //loops through inputs besides first and last (excludes function call and test language)

    for(int i = 1; i <= argc-2; i++){

        //adds frequencies to vectors

        frequencies temp = frequencies(argv[i]);
        languageFreq.push_back(temp);

    }

    //gets test frequencies

    frequencies test(argv[argc-1]);

    //intializes lowest possible similarity
    //saves first index as max

    double sim = 0;
    int max_i = 0;

    //max function for highest similarity(saves index of the max)

    for(size_t i = 0; i < languageFreq.size(); i++){
        double temp = test.similarity(languageFreq[i]);
        if ( temp > sim) {sim = temp; max_i = i;}
    }

    //prints highest max file name
    std::cout<<argv[max_i + 1]<<std::endl;

}