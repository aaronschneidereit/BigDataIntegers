/**
 * Started by Najib 3/21/18
 **/


///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include "functions.h"
#include "bigint/bigint.h"


///////////////////////////////////////////////////////////////////
// FUNCTION DEFINITIONS GO HERE
///////////////////////////////////////////////////////////////////

//Default constructor

frequencies::frequencies(){

    //clears trFreq

    triFreq.clear();

    //creates a triFreq full of 0s

    for(int i = 0; i < 17576; i++){

        //adds zeros to triFreq

        triFreq.push_back(0);
    }
}

//Filename constructor

frequencies::frequencies(std::string filename){

    //clears triFreq

    triFreq.clear();

    //Intializes file stream

    std::ifstream infile;

    //Opens the file as a c string

    infile.open(filename.c_str());

    //Initalizes strings and chars thagt will be used

    std::string temp;
    std::string str;
    char ch;
    char newCh;

    //Intialiezes counter

    int counter = 0;

    //Recreates triFreq

    for(int i = 0; i < 17576; i++){
        triFreq.push_back(0);
    }

    //Reads char by char

    while (infile.get(ch)) {

        //Checks the counter (hence size of the trigram)

        if(counter > 2){

            //Resets expon and j

            int expon = 2;
            int j = 0;

            //Loops through 3 times

            for(int i = 0; i < 3; i++){

                //Sets the index to the current character

                char index = str[i];

                //calculates the value of each letter in order from 26^2 to 26^0

                j += (int(index) - 97) * pow(26, expon);

                //subtracts exponent for next number

                expon -= 1;
            }

            //adds one to the frequency position in the vector

            triFreq[j] += 1;

            //gets the last two characters of str

            temp = str.substr(1,2);

            //sets str equal to temp

            str = temp;

            //reset counter to 2

            counter = 2;
        }

        //checks for capital letters

        if(ch >= 65 && ch <= 90){

            //sets cpas to lower

            newCh = tolower(ch);

            //adds lowercase t str

            str += newCh;

            //increases counter

            counter++;

        }

        //checks for lower case letter

        else if(ch >= 97 && ch <= 122){

            //adds char to str

            str += ch;

            //increases counter

            counter++;
        }

        //anything that isnt a letter

        else{

            //ignores char, continues through reading

            continue;
        }

    }

    infile.close();

}

//returns the frequency vector of a file

std::vector<int> frequencies::getTriFreq(){//gets the frequenices
    return triFreq;
}

//Algorithm for the dot product

bigint dotproduct(std::vector<int> a, std::vector<int> b){

    bigint product;

    //loops through frequencies, multiplies indexes together

    for(int i = 0; i < (int)a.size(); i++){
        bigint Ai = a[i];
        bigint Bi = b[i];
        product += (Ai*Bi);
    }

    //sends back the dot product

    return product;
}

//calculates numerator of cos^2

bigint numerator(bigint num){

    //squares number given

    num = num.fast_pow(2);

    //multiplies by a million

    num = num*1000000;

    //sends back result

    return num;
}

//calcultes denominator of cos^2 function

bigint divide(bigint num, bigint den1, bigint den2){

    //uses bigint fast divide and fast mulitply to get unsimlified cos^2

    return (num / (den1 * den2));
}

double frequencies::similarity(frequencies languageFreq){


    // sets b equal to vecvec of language freq

    std::vector <int> b = languageFreq.getTriFreq();

    //gets do product of numerator

    bigint dot = dotproduct(triFreq,b);

    //gets the value of the numerator

    bigint numer = numerator(dot);

    //gets summation of a^2 for denominator

    bigint denom1 = dotproduct(triFreq,triFreq);

    //gets summation of b^2 for denominator

    bigint denom2 = dotproduct(b,b);

    //gets the unsimplified cos^2

    bigint divi = divide(numer, denom1, denom2);

    //converts unsimplied cos^2 to a string

    std::string result = divi.to_string(false);

    //converts string of unsimpliifed cos^2 to a double

    double product = std::stod(result);

    //simpliesfies cos^2 to get rid of 1000000 scale

    product /= 1000000;

    //simplifies cos^2 by gettign sqrt (undoing the sqauring of a^2 and b^2 scale)

    double answer = sqrt(product);

    //sends back cos^2 of the trigram frequencies

    return answer;

}



